
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.annotations.Test;

public class GoogleTEst {

	public String baseUrl = "http://www.google.co.in/";
	


	@Test
	public void verifyHomePageTitle() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		driver.get(baseUrl);

		
		WebElement element = driver.findElement(By.name("q"));

		// Enter something to search for

		element.sendKeys("Cheese!");

		// Now submit the form. WebDriver will find the form for us from the
		// element

		element.submit();

		// Check the title of the page

		System.out.println("Page title is: " + driver.getTitle());

		driver.quit();

	}

}