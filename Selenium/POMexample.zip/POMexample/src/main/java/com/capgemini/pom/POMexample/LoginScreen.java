package com.capgemini.pom.POMexample;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginScreen {

	WebDriver driver;
	@FindBy(id = "uname")
	WebElement username;
	@FindBy(id = "password")
	WebElement password;
	@FindBy(id = "sub")
	WebElement login;

	public LoginScreen(WebDriver log) {
		driver = log;
		PageFactory.initElements(driver, this);//will initiate page web elements
	}

	public void LoginScreen1(String uname, String password)
			throws InterruptedException {
		this.setUserName(uname);
		this.setPassword(password);
		Thread.sleep(1000);
		clickme();
	}

	public void setUserName(String uname) {
		username.sendKeys(uname);
	}

	public void setPassword(String pass) {
		password.sendKeys(pass);
	}

	public void clickme() {
		login.click();
	}

}
