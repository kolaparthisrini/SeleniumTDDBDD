package com.capgemini.testing;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.pom.POMexample.LoginScreen;

public class TestingMe {

	WebDriver driver;
	LoginScreen scr;
	
	@Before
	public void pre() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\soft\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:7778/SeleniumWebApp/login.html");
	}
	
	@Test
	public void middle() throws InterruptedException
	{
		
		scr = new LoginScreen(driver);
		scr.LoginScreen1("srinivas","kolaparthi");
	}
	
	@Test
	public void closeme()
	{
		driver.quit();
	}
}
