package com.cg.Selenium.SeleniumTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://www.irctc.co.in");
		driver.manage().window().maximize();
		List<WebElement> ls = driver.findElements(By.tagName("img"));
		System.out.print(ls.size());
		try {
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
