package com.cg.Selenium.SeleniumTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ChromeTesting {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		driver.manage().window().maximize();
		driver.quit();

		System.setProperty("webdriver.firefox.driver",
				"D:\\FUTURENOVA\\selenium\\geckodriver-v0.20.1-win64\\geckodriver.exe");
		WebDriver driver1 = new FirefoxDriver();
		driver1.navigate().to("http://www.google.com");
		driver1.manage().window().maximize();
		driver1.quit();
	}

}
