package com.cg.Selenium.SeleniumTest;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;

import org.monte.media.math.Rational;
import org.monte.media.Format;
import org.monte.screenrecorder.ScreenRecorder;

import static org.monte.media.AudioFormatKeys.*;
import static org.monte.media.VideoFormatKeys.*;

import java.awt.AWTException;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class RecordingDemo {
   private static ScreenRecorder screenRecorder;
   
   public static void main(String[] args) throws IOException, AWTException, InterruptedException {
      GraphicsConfiguration gconfig = GraphicsEnvironment
         .getLocalGraphicsEnvironment()
         .getDefaultScreenDevice()
         .getDefaultConfiguration();
      
      screenRecorder = new ScreenRecorder(gconfig,
         new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
         new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey,
            ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
            CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
            DepthKey, (int)24, FrameRateKey, Rational.valueOf(15),
            QualityKey, 1.0f,
            KeyFrameIntervalKey, (int) (15 * 60)),
         new Format(MediaTypeKey, MediaType.VIDEO,
            EncodingKey,"black", FrameRateKey, Rational.valueOf(30)), null);
      
      System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
      // Start Capturing the Video
      screenRecorder.start();
      
      // Puts an Implicit wait, Will wait for 10 seconds before throwing exception
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
      // Launch website
      driver.navigate().to("http://www.jenkins.io/");
      
      // Maximize the browser
      driver.manage().window().maximize();
      

      File screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
      FileUtils.copyFile(screenshot, new File("D:\\screenshots\\screenshots1.jpg"));
Thread.sleep(1000);
      // Print a Log In message to the screen
      // Close the Browser.
      driver.quit();
      
      // Stop the ScreenRecorder
      screenRecorder.stop();
   }
}