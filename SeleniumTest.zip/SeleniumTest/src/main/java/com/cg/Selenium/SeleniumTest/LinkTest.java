package com.cg.Selenium.SeleniumTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		driver.manage().window().maximize();
		List <WebElement> ls=driver.findElements(By.tagName("a"));
		System.out.println(ls.size());
		for(int i=1;i<=ls.size();i++)
		{
			//System.out.println(ls.get(i).getText());
		}
		
		driver.quit();
	}

}
