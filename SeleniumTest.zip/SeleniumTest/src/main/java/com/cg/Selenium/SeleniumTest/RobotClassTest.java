package com.cg.Selenium.SeleniumTest;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

@SuppressWarnings("unused")
public class RobotClassTest {

	@Test
	public void TestRobo() throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.facebook.com");
		driver.findElement(By.id("email")).sendKeys("Selenium@gmail.com");
		driver.findElement(By.id("pass")).sendKeys("mukesh");
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		driver.quit();
	}

}