package com.cg.Selenium.SeleniumTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * Hello world!
 *
 */
public class IETest 
{
    public static void main( String[] args )
    {
    	 System.setProperty("webdriver.ie.driver", "D:\\FUTURENOVA\\selenium\\IEDriverServer_Win32_2.48.0\\IEDriverServer.exe");  
    	 DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
    	 capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);

         // Instantiate a IEDriver class.       
      WebDriver driver=new InternetExplorerDriver(capabilities);  
        
        
      driver.navigate().to("http://www.google.com/");  
        
        
        driver.manage().window().maximize();  
          
    
      driver.findElement(By.name("q")).sendKeys("Selenium");  
            
         // Click on the search button  
      driver.findElement(By.name("btnK")).submit();  
      driver.quit();
    }
}
