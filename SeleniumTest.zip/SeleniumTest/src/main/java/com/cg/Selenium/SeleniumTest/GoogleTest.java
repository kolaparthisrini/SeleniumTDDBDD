package com.cg.Selenium.SeleniumTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GoogleTest {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + 
		"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://localhost:4444//SeleniumWebPages//index.html");
		driver.manage().window().maximize();
		// System.out.println(driver.findElement(By.name("submit")).getAttribute("value"));
		/*
		 * if(driver.findElement(By.name("submit")).getAttribute("value").equals
		 * ("submit")) { driver.findElement(By.name("uname")).clear();
		 * //driver.findElement(By.name("submit")).submit(); }
		 */
		driver.findElement(By.name("uname")).sendKeys("capgemini");
		Select comp = new Select(driver.findElement(By.id("comp")));
		comp.selectByIndex(2);
		driver.findElement(By.name("red")).click();
		Thread.sleep(10000);
		driver.findElement(By.name("red")).clear();
		Thread.sleep(10000);
		driver.quit();
	}
}
