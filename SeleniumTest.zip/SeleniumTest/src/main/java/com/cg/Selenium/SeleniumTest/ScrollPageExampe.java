package com.cg.Selenium.SeleniumTest;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ScrollPageExampe {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver",
				"D:\\FUTURENOVA\\selenium\\chromedriver_win32\\" + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("http://amazon.com");
		// Wait for 5 second
		Thread.sleep(5000);
		((JavascriptExecutor) driver).executeScript
		("window.scrollBy(0,345)");
		//driver.quit();
	}
}
